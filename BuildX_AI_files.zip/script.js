const idea = document.getElementById("idea");
const buildBtn = document.getElementById("buildBtn");
const result = document.getElementById("result");

buildBtn.addEventListener("click", () => {
  const text = idea.value.trim();

  if (!text) {
    result.classList.remove("hidden");
    result.textContent = "Please describe what you want to build first. 🚀";
    return;
  }

  result.classList.remove("hidden");
  result.innerHTML = `
    <strong>BuildX AI received your idea! 🚀</strong><br><br>
    <b>Your idea:</b> ${escapeHtml(text)}<br><br>
    This MVP is ready for the next stage: connecting it to a real AI backend
    so BuildX AI can generate actual apps from the user's description.
  `;
});

function escapeHtml(value) {
  const div = document.createElement("div");
  div.textContent = value;
  return div.innerHTML;
}
